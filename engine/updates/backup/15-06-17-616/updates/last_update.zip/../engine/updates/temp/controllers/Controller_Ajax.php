<?php

class Controller_Ajax extends Controller 
{
    public function __construct() {
        //
    }
}
