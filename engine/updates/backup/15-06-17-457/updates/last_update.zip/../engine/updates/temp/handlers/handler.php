<?php 

    require_once '../core/db.php';
    require_once '../controllers/Controller_Functions.php';
    require_once '../core/shopengine.php';
    
    Controller_Functions::start();